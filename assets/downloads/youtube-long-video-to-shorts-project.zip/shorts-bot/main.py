#!/usr/bin/env python3
"""
Paste a YouTube or Twitch link -> find the best moments -> make vertical Shorts -> upload.

Pipeline
  1. yt-dlp downloads the video (max 720p to save disk and time)
  2. FFmpeg measures loudness every second; the biggest spikes become candidates
  3. Small 360p copies of each candidate are sent to Gemini, which scores them
     and picks the best 20-45 seconds inside each one
  4. FFmpeg renders 9:16 clips (gameplay centered over a blurred background)
  5. The YouTube Data API uploads them as Shorts
"""
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

WORK = Path("work")
OUT = Path("out")
PROCESSED = Path("processed.json")

SR = 8000                      # audio sample rate used for loudness analysis
WIN_BEFORE = 25                # seconds kept before a loudness peak
WIN_AFTER = 25                 # seconds kept after it
MIN_GAP = 90                   # candidates must be at least this far apart (s)
N_CANDIDATES = int(os.getenv("N_CANDIDATES", "15"))
BATCH = 5                      # clips sent to Gemini per request
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-latest")
MAX_SHORT_SECONDS = 58
MIN_SHORT_SECONDS = 15

FORMAT = "bv*[height<=720]+ba/b[height<=720]/b"

PROMPT = """You are an editor choosing moments for YouTube Shorts from a gameplay video.
Below are several CLIPs, each an excerpt of about 50 seconds. For EVERY clip:
- judge how good the best moment inside it is for a Short (action, funny reaction,
  surprise, clear payoff, strong audio energy)
- choose the best sub-range of 20-45 seconds: start just BEFORE the action begins,
  end shortly AFTER the payoff
- score boring, menu, loading or dead-air clips 3 or lower

Return ONLY a JSON array with one object per clip:
{"clip": <clip number>, "score": <1-10>, "start": <seconds from clip start>,
 "end": <seconds from clip start>, "title": "<catchy title, under 70 characters, no hashtags>"}
"""


# --------------------------------------------------------------------------- helpers
def run(cmd, **kw):
    print("+", " ".join(str(c) for c in cmd), flush=True)
    return subprocess.run(cmd, check=True, **kw)


def cookie_args():
    return ["--cookies", "cookies.txt"] if Path("cookies.txt").exists() else []


def load_processed():
    try:
        return json.loads(PROCESSED.read_text())
    except Exception:
        return {}


def save_processed(data):
    PROCESSED.write_text(json.dumps(data, indent=2))


def summary(text):
    path = os.getenv("GITHUB_STEP_SUMMARY")
    if path:
        with open(path, "a") as f:
            f.write(text + "\n")
    print(text, flush=True)


# --------------------------------------------------------------------------- download
def get_info(url):
    cmd = ["yt-dlp", "--no-playlist", "--skip-download", "--dump-single-json",
           *cookie_args(), url]
    try:
        out = subprocess.run(cmd, check=True, capture_output=True, text=True).stdout
    except subprocess.CalledProcessError as e:
        print(e.stderr)
        if "not a bot" in (e.stderr or ""):
            print("\nYouTube blocked the cloud IP. Add a YT_COOKIES secret (see README).")
        elif "subscriber" in (e.stderr or "").lower():
            print("\nThis Twitch VOD is subscriber-only, so it cannot be downloaded.")
        sys.exit(1)
    return json.loads(out)


def download(url):
    WORK.mkdir(exist_ok=True)
    run(["yt-dlp", "--no-playlist", "-f", FORMAT, "--merge-output-format", "mp4",
         "--concurrent-fragments", "4", "--retries", "10", "--fragment-retries", "10",
         "-o", str(WORK / "source.%(ext)s"), *cookie_args(), url])
    mp4 = WORK / "source.mp4"
    if mp4.exists():
        return mp4
    files = [p for p in WORK.glob("source.*") if p.suffix not in (".part", ".ytdl")]
    if not files:
        raise RuntimeError("Download finished but no video file was found")
    return files[0]


def duration(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=nw=1:nk=1", str(path)],
        capture_output=True, text=True, check=True).stdout
    return float(out.strip())


# --------------------------------------------------------------------------- find moments
def loudness_per_second(src):
    """RMS loudness for every second of audio, read in 10-minute blocks."""
    cmd = ["ffmpeg", "-v", "error", "-i", str(src), "-vn", "-ac", "1",
           "-ar", str(SR), "-f", "s16le", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    sec_bytes = SR * 2
    leftover = b""
    parts = []
    while True:
        data = proc.stdout.read(sec_bytes * 600)
        if not data:
            break
        data = leftover + data
        usable = (len(data) // sec_bytes) * sec_bytes
        leftover = data[usable:]
        if usable == 0:
            continue
        a = np.frombuffer(data[:usable], dtype=np.int16).astype(np.float32).reshape(-1, SR)
        parts.append(np.sqrt((a * a).mean(axis=1)))
    proc.wait()
    return np.concatenate(parts) if parts else np.array([], dtype=np.float32)


def moving_avg(x, k):
    k = max(1, min(k, len(x)))
    if k % 2 == 0:
        k -= 1
    pad = k // 2
    xp = np.pad(x, (pad, pad), mode="edge")
    return np.convolve(xp, np.ones(k) / k, mode="valid")


def pick_peaks(rms, n, min_gap):
    """Seconds where loudness jumps far above the surrounding baseline."""
    if len(rms) < 120:
        return []
    short = moving_avg(rms, 5)
    long_ = moving_avg(rms, 181)
    jump = short / (long_ + 0.02 * long_.max() + 1e-3)
    loud = short / (short.max() + 1e-6)
    score = jump * (0.5 + loud)
    chosen = []
    for i in np.argsort(score)[::-1]:
        i = int(i)
        if i < 20 or i > len(rms) - 20:
            continue
        if all(abs(i - j) >= min_gap for j in chosen):
            chosen.append(i)
        if len(chosen) >= n:
            break
    return sorted(chosen)


def cut_proxy(src, start, dur, dst):
    run(["ffmpeg", "-y", "-v", "error", "-ss", f"{start:.2f}", "-i", str(src),
         "-t", f"{dur:.2f}", "-vf", "scale=-2:360", "-r", "12",
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "34",
         "-c:a", "aac", "-b:a", "48k", "-ac", "1", str(dst)])


# --------------------------------------------------------------------------- gemini
def parse_json(text):
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    return json.loads(text)


def gemini_rank(clips):
    """Returns {clip_id: {score, start, end, title}} or {} if Gemini is unavailable."""
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        print("No GEMINI_API_KEY set; using audio-only picks.")
        return {}
    try:
        from google import genai
        from google.genai import types
    except ImportError:
        print("google-genai is not installed; using audio-only picks.")
        return {}

    client = genai.Client(api_key=key)
    results = {}
    for b in range(0, len(clips), BATCH):
        batch = clips[b:b + BATCH]
        try:
            files = []
            for c in batch:
                f = client.files.upload(file=str(c["path"]))
                while f.state and f.state.name == "PROCESSING":
                    time.sleep(2)
                    f = client.files.get(name=f.name)
                files.append(f)
            contents = [PROMPT]
            for c, f in zip(batch, files):
                contents += [f"CLIP {c['id']} (length {c['win_dur']:.0f} seconds):", f]

            resp = None
            for attempt in range(5):
                try:
                    resp = client.models.generate_content(
                        model=GEMINI_MODEL, contents=contents,
                        config=types.GenerateContentConfig(
                            response_mime_type="application/json", temperature=0.3))
                    break
                except Exception as e:  # rate limit or temporary error
                    wait = 20 * (attempt + 1)
                    print(f"Gemini error: {e}\nretrying in {wait}s", flush=True)
                    time.sleep(wait)
            if resp is None:
                continue
            for item in parse_json(resp.text):
                results[int(item["clip"])] = item
        except Exception as e:
            print(f"Batch {b // BATCH + 1} failed: {e}")
        if b + BATCH < len(clips):
            time.sleep(20)  # stay under free-tier tokens-per-minute limit
    return results


# --------------------------------------------------------------------------- render
FILTER = (
    "[0:v]split=2[bg][fg];"
    "[bg]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=25:5[b];"
    "[fg]scale=1080:-2[f];"
    "[b][f]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]"
)


def render_short(src, start, dur, dst):
    run(["ffmpeg", "-y", "-v", "error", "-ss", f"{start:.2f}", "-i", str(src),
         "-t", f"{dur:.2f}", "-filter_complex", FILTER, "-map", "[v]", "-map", "0:a?",
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-r", "30",
         "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dst)])


# --------------------------------------------------------------------------- youtube upload
def youtube_client():
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    creds = Credentials(
        None,
        refresh_token=os.environ["YT_REFRESH_TOKEN"],
        token_uri="https://oauth2.googleapis.com/token",
        client_id=os.environ["YT_CLIENT_ID"],
        client_secret=os.environ["YT_CLIENT_SECRET"],
        scopes=["https://www.googleapis.com/auth/youtube.upload"],
    )
    return build("youtube", "v3", credentials=creds, cache_discovery=False)


def clean(text):
    return re.sub(r"[<>]", "", text or "").strip()


def upload_short(yt, path, title, description, privacy):
    from googleapiclient.http import MediaFileUpload
    body = {
        "snippet": {
            "title": f"{clean(title)[:85]} #Shorts",
            "description": description,
            "tags": ["Shorts", "gaming", "gameplay"],
            "categoryId": "20",  # Gaming
        },
        "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False},
    }
    media = MediaFileUpload(str(path), mimetype="video/mp4", chunksize=-1, resumable=True)
    req = yt.videos().insert(part="snippet,status", body=body, media_body=media)
    resp = None
    while resp is None:
        _, resp = req.next_chunk()
    return resp["id"]


# --------------------------------------------------------------------------- main
def main():
    url = os.environ["VIDEO_URL"].strip()
    max_shorts = max(1, int(os.getenv("MAX_SHORTS", "3") or 3))
    privacy = os.getenv("PRIVACY", "private")
    force = os.getenv("FORCE", "false").lower() == "true"

    missing = [k for k in ("YT_CLIENT_ID", "YT_CLIENT_SECRET", "YT_REFRESH_TOKEN")
               if not os.getenv(k)]
    if missing:
        sys.exit(f"Missing secrets: {', '.join(missing)}. See README step 5.")

    info = get_info(url)
    if info.get("is_live"):
        sys.exit("This stream is still live. Run again after it ends and the VOD is ready.")
    vid_key = f"{info.get('extractor_key')}:{info.get('id')}"
    title = info.get("title") or "video"
    uploader = info.get("uploader") or info.get("channel") or "the original creator"

    processed = load_processed()
    if vid_key in processed and not force:
        summary(f"Already processed {vid_key}. Tick 'force' to run it again.")
        return
    summary(f"### {clean(title)}\nSource: {url} ({uploader})")

    OUT.mkdir(exist_ok=True)
    src = download(url)
    total = duration(src)
    summary(f"Downloaded {total / 60:.0f} minutes of video.")

    rms = loudness_per_second(src)
    peaks = pick_peaks(rms, N_CANDIDATES, MIN_GAP)
    if not peaks:
        sys.exit("Could not find any candidate moments (video too short or silent).")
    print(f"{len(peaks)} candidate moments at seconds: {peaks}")

    # small 360p copies for Gemini
    clips = []
    for i, t in enumerate(peaks):
        ws = max(0.0, t - WIN_BEFORE)
        we = min(total, t + WIN_AFTER)
        path = WORK / f"cand_{i}.mp4"
        cut_proxy(src, ws, we - ws, path)
        clips.append({"id": i, "peak": t, "win_start": ws, "win_dur": we - ws, "path": path})

    ranked = gemini_rank(clips)
    print(f"Gemini scored {len(ranked)} of {len(clips)} clips.")

    plans = []
    for c in clips:
        r = ranked.get(c["id"])
        if r:
            s, e, score = float(r["start"]), float(r["end"]), float(r["score"])
            ttl = r.get("title") or f"Best moment from {clean(title)[:50]}"
        else:  # fallback: window around the loudness peak
            s, e, score = c["peak"] - c["win_start"] - 15, c["peak"] - c["win_start"] + 20, 5.0
            ttl = f"Best moment from {clean(title)[:50]}"
        s = max(0.0, min(s, c["win_dur"] - MIN_SHORT_SECONDS))
        e = min(c["win_dur"], max(e, s + MIN_SHORT_SECONDS))
        if e - s > MAX_SHORT_SECONDS:
            e = s + MAX_SHORT_SECONDS
        plans.append({"score": score, "abs_start": c["win_start"] + s,
                      "dur": e - s, "title": ttl})

    plans.sort(key=lambda p: p["score"], reverse=True)
    chosen = [p for p in plans if p["score"] >= 4][:max_shorts] or plans[:1]

    yt = youtube_client()
    uploaded = []
    for n, p in enumerate(chosen, 1):
        dst = OUT / f"short_{n}.mp4"
        render_short(src, p["abs_start"], p["dur"], dst)
        desc = (f"#Shorts #gaming\n\nOriginal video: {clean(title)} by {clean(uploader)}\n{url}")
        try:
            vid = upload_short(yt, dst, p["title"], desc, privacy)
            uploaded.append(vid)
            summary(f"- Short {n} (score {p['score']:.0f}): https://youtube.com/shorts/{vid} "
                    f"({privacy}) - {clean(p['title'])}")
        except Exception as e:
            summary(f"- Short {n} FAILED to upload: {e}. The clip is saved in the 'shorts' artifact.")

    if uploaded:
        processed[vid_key] = {"url": url, "date": datetime.now(timezone.utc).isoformat(),
                              "uploaded": uploaded}
        save_processed(processed)
    else:
        sys.exit("No Shorts were uploaded. Check the log above.")


if __name__ == "__main__":
    main()
