# Paste a link, get Shorts

Paste a YouTube or Twitch link into a GitHub "Run workflow" box. The cloud downloads the video, finds the best moments, cuts them into vertical 9:16 clips, and uploads them to your YouTube channel as Shorts. Nothing runs on your PC and every service used has a free tier.

**Use it only on videos you are allowed to clip** (your own, or creators who allow it). Every upload credits the original video and link in the description.

## One-time setup

### 1. GitHub repo
Create a new repo and upload everything in this folder (keep the `.github/workflows` path).
Private repo: 2,000 free Actions minutes per month. Public repo: unlimited, but your logs and `processed.json` are visible. Check GitHub's current limits.

### 2. Gemini API key (free)
Go to https://aistudio.google.com/apikey and create a key.

### 3. Google Cloud project for YouTube uploads
1. https://console.cloud.google.com -> create a project.
2. APIs & Services -> Library -> enable **YouTube Data API v3**.
3. APIs & Services -> OAuth consent screen (or "Google Auth Platform") -> User type **External** -> fill the basics.
4. Add the scope `https://www.googleapis.com/auth/youtube.upload` and add your own Google account as a **test user**.
5. Credentials -> Create credentials -> OAuth client ID -> type **Web application**.
   Under "Authorized redirect URIs" add exactly: `https://developers.google.com/oauthplayground`
6. Copy the **Client ID** and **Client secret**.
7. **Publish the app** (consent screen / Audience -> "Publish app" -> In production). Do this BEFORE the next step. If it stays in "Testing", your login token dies after 7 days. The "unverified app" warning is normal for personal use.

### 4. Get your refresh token (no install needed)
1. Open https://developers.google.com/oauthplayground
2. Click the gear icon -> tick **Use your own OAuth credentials** -> paste your Client ID and secret.
3. In the left box, type `https://www.googleapis.com/auth/youtube.upload` -> Authorize APIs -> choose the YouTube channel you want to post to.
4. Click **Exchange authorization code for tokens** and copy the **Refresh token**.

### 5. Add GitHub secrets
Repo -> Settings -> Secrets and variables -> Actions -> New repository secret:

| Name | Value |
|---|---|
| `GEMINI_API_KEY` | key from step 2 |
| `YT_CLIENT_ID` | from step 3 |
| `YT_CLIENT_SECRET` | from step 3 |
| `YT_REFRESH_TOKEN` | from step 4 |
| `YT_COOKIES` | optional, see YouTube note below |

## Using it
Repo -> **Actions** -> **Make Shorts** -> **Run workflow** -> paste the link -> Run.
Results (links to the new Shorts) appear in the run summary. Finished clips are also kept for 3 days under "Artifacts".

Start with `private` (the default), check the results, then switch to `unlisted` or `public`.

## How it picks moments
1. Downloads the video at up to 720p.
2. Measures loudness every second and picks the biggest spikes (reactions, fights, crashes).
3. Sends small 360p copies of about 15 of them to Gemini, which scores each and picks the best 20-45 seconds.
4. Renders the top ones (default 3) as 1080x1920 with the gameplay centered over a blurred background.
5. If Gemini is down or rate-limited, it falls back to the loudness picks.

## Notes and fixes
- **Twitch:** works without any extra setup. Subscriber-only VODs cannot be downloaded. Wait for a live stream to end before using its VOD link.
- **YouTube:** YouTube often blocks cloud IPs. The workflow starts a PO-token helper that fixes many cases. If you still see "Sign in to confirm you're not a bot", export `cookies.txt` (Netscape format) from a spare Google account using a browser extension and paste the whole file into the `YT_COOKIES` secret. Cookies expire, so refresh them if it starts failing again.
- **Uploads stay private?** Google says uploads from unverified API projects may be locked to private. Test once. If they are locked, make them public in YouTube Studio, or apply for Google's free API compliance audit.
- **Daily limits:** YouTube API quota allows far more uploads than you need. Gemini's free tier is rate-limited, so the script batches and waits.
- **Model name:** default is `gemini-flash-latest`. Set a `GEMINI_MODEL` env var in the workflow if you want a specific model.
- **Long streams:** a 5-hour 720p VOD can take several GB of the runner's disk (about 14 GB). If it fails with a disk error, use shorter videos.
- **Repeats:** processed videos are recorded in `processed.json`. Tick "force" to run one again.
